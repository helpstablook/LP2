﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrjCalculadora
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        private bool ValidarNumeros(out double n1, out double n2)
        {
            if (!double.TryParse(txtN1.Text, out n1))
            {
                MessageBox.Show("Primeiro número inválido!");
                txtN1.Focus();
                n2 = 0;
                return false;
            }

            if (!double.TryParse(txtN2.Text, out n2))
            {
                MessageBox.Show("Segundo número inválido!");
                txtN2.Focus();
                return false;
            }

            return true;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            txtResult.Clear();
            txtN1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros(out double n1, out double n2))
            {
                txtResult.Text = (n1 + n2).ToString();
            }
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros(out double n1, out double n2))
            {
                txtResult.Text = (n1 - n2).ToString();
            }
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros(out double n1, out double n2))
            {
                txtResult.Text = (n1 * n2).ToString();
            }
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (ValidarNumeros(out double n1, out double n2))
            {
                if (n2 == 0)
                {
                    MessageBox.Show("Não pode dividir por zero!");
                    return;
                }

                txtResult.Text = (n1 / n2).ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
