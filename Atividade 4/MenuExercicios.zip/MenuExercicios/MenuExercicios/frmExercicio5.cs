﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuExercicios
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int Num1=0, Num2=0;

            if (!int.TryParse(txtNum1.Text, out Num1) || (Num1 <= 0))
            {
                MessageBox.Show("Número 1 inválido");
                txtNum1.Focus();
            }
            else if (!int.TryParse(txtNum2.Text, out Num2) || (Num2 <= 0))
            {
                MessageBox.Show("Número 2 inválido");
                txtNum2.Focus();
            }
            else if (Num1 > Num2)
            {
                MessageBox.Show("Número 1 maior que Número 2");
                txtNum1.Focus();
            }
            else 
            {
                Random ObjR = new Random();
                int sorteado = ObjR.Next(Num1, Num2);

                MessageBox.Show("Número sorteado é: " + sorteado);
                txtNum1.Focus();
            }
        }
    }
}
