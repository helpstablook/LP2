﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MenuExercicios
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void rcRtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int contaNum = 0;

            while(posicao < rcRtxtFrase.Text.Length)
            {
                if (char.IsNumber(rcRtxtFrase.Text[posicao]))
                {
                    contaNum++;
                }

                posicao++;
            }

            MessageBox.Show($" a frase tem {contaNum} números");
        }

        private void btnLocaliza_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rcRtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rcRtxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break;
                }
            }

            if (posicao > 0)
                MessageBox.Show($" o 1º caracter em branco está na posição {posicao}");
            else
                MessageBox.Show("Não há caracteres em branco");
        }

        private void btnContaLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;

            foreach (char c in rcRtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {  
                    contaLetra++; 
                }
            }

            MessageBox.Show($"a frase tem {contaLetra} letras");
        }
    }
}
