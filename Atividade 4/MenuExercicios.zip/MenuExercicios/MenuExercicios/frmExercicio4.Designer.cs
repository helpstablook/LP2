﻿namespace MenuExercicios
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rcRtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.btnLocaliza = new System.Windows.Forms.Button();
            this.btnContaLetras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rcRtxtFrase
            // 
            this.rcRtxtFrase.Location = new System.Drawing.Point(77, 30);
            this.rcRtxtFrase.Name = "rcRtxtFrase";
            this.rcRtxtFrase.Size = new System.Drawing.Size(674, 264);
            this.rcRtxtFrase.TabIndex = 0;
            this.rcRtxtFrase.Text = "";
            this.rcRtxtFrase.TextChanged += new System.EventHandler(this.rcRtxtFrase_TextChanged);
            // 
            // btnContaNum
            // 
            this.btnContaNum.Location = new System.Drawing.Point(82, 364);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(195, 70);
            this.btnContaNum.TabIndex = 1;
            this.btnContaNum.Text = "Conta Números";
            this.btnContaNum.UseVisualStyleBackColor = true;
            this.btnContaNum.Click += new System.EventHandler(this.btnContaNum_Click);
            // 
            // btnLocaliza
            // 
            this.btnLocaliza.Location = new System.Drawing.Point(323, 364);
            this.btnLocaliza.Name = "btnLocaliza";
            this.btnLocaliza.Size = new System.Drawing.Size(195, 70);
            this.btnLocaliza.TabIndex = 2;
            this.btnLocaliza.Text = "Localiza 1º Caracter em Branco";
            this.btnLocaliza.UseVisualStyleBackColor = true;
            this.btnLocaliza.Click += new System.EventHandler(this.btnLocaliza_Click);
            // 
            // btnContaLetras
            // 
            this.btnContaLetras.Location = new System.Drawing.Point(561, 364);
            this.btnContaLetras.Name = "btnContaLetras";
            this.btnContaLetras.Size = new System.Drawing.Size(195, 70);
            this.btnContaLetras.TabIndex = 3;
            this.btnContaLetras.Text = "Conta Letras";
            this.btnContaLetras.UseVisualStyleBackColor = true;
            this.btnContaLetras.Click += new System.EventHandler(this.btnContaLetras_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 510);
            this.Controls.Add(this.btnContaLetras);
            this.Controls.Add(this.btnLocaliza);
            this.Controls.Add(this.btnContaNum);
            this.Controls.Add(this.rcRtxtFrase);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MinimizeBox = false;
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rcRtxtFrase;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.Button btnLocaliza;
        private System.Windows.Forms.Button btnContaLetras;
    }
}