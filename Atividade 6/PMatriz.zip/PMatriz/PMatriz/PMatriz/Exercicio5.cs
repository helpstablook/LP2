﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void Exercicio5_Load(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int N = 2;
            char[,] respostasAlunos = new char[N, 10];
            char[] gabarito = { 'A', 'B', 'C', 'D', 'E', 'A', 'B', 'C', 'D', 'E' };

            lstResultado.Items.Clear();

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    bool respostaValida = false;
                    while (!respostaValida)
                    {
                        string input = Interaction.InputBox($"Aluno {i + 1}\nDigite a resposta da questão {j + 1} (A, B, C, D ou E):", "Exercício 5", "");

                        if (input == null || input.Length == 0)
                        {
                            var resposta = MessageBox.Show("Deseja realmente interromper a execução do Exercício 5?", "Cancelar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                            if (resposta == DialogResult.Yes)
                            {
                                return;
                            }
                            else
                            {
                                continue;
                            }
                        }

                        input = input.ToUpper();

                        if (input == "A" || input == "B" || input == "C" || input == "D" || input == "E")
                        {
                            respostasAlunos[i, j] = char.Parse(input);
                            respostaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Resposta inválida! Digite apenas A, B, C, D ou E.");
                        }
                    }
                }
            }

            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    char respostaEscolhida = respostasAlunos[i, j];
                    char respostaCorreta = gabarito[j];
                    string status = (respostaEscolhida == respostaCorreta) ? "acertou" : "errou";
                    string linhaResultado = $"aluno:{i + 1} {status} questão:{j + 1} era {respostaCorreta} escolheu {respostaEscolhida}";
                    lstResultado.Items.Add(linhaResultado);
                }
                lstResultado.Items.Add("");
            }
        }
    }
}