﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void Exercicio4_Load(object sender, EventArgs e)
        {
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] tamanhos = new int[10];
            lstResultado.Items.Clear();

            for (int i = 0; i < 10; i++)
            {
                bool nomeValido = false;
                while (!nomeValido)
                {
                    string nome = Interaction.InputBox($"Digite o nome completo da {i + 1}ª pessoa:", "Exercício 4", "");

                    if (nome == null || nome.Length == 0)
                    {
                        var resposta = MessageBox.Show("Deseja realmente interromper a execução do exercício?", "Cancelar", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (resposta == DialogResult.Yes)
                        {
                            return;
                        }
                        else
                        {
                            continue;
                        }
                    }

                    if (string.IsNullOrWhiteSpace(nome))
                    {
                        MessageBox.Show("O nome não pode estar vazio. Por favor, digite um nome válido.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        nomes[i] = nome;
                        string nomeSemEspaco = nome.Replace(" ", "");
                        tamanhos[i] = nomeSemEspaco.Length;

                        nomeValido = true;
                    }
                }
            }

            for (int i = 0; i < 10; i++)
            {
                lstResultado.Items.Add($"O nome: {nomes[i]} tem {tamanhos[i]} caracteres");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}