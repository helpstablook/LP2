﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            String aux = "";
            for (int i = 0; i < Vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o número {i + 1}", "Entrada de dados");
                if (!int.TryParse(aux, out Vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                }
                i++;
            }
            Array.Reverse(Vetor);
            aux = "";
            foreach (int x in Vetor)
                aux += x + "\n";
            MessageBox.Show(aux);
        }

        private void btnEx2_Click_1(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList();
            alunos.Add("Ana");
            alunos.Add("André");
            alunos.Add("Beatriz");
            alunos.Add("Camila");
            alunos.Add("João");
            alunos.Add("Joana");
            alunos.Add("Otávio");
            alunos.Add("Marcelo");
            alunos.Add("Pedro");
            alunos.Add("Thais");

            alunos.Remove("Otávio");
            string resultado = string.Join("\n", alunos.Cast<string>());
            MessageBox.Show(resultado);

        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            
            double[,] notas = new double[20, 3];
            string resultado = "";

        
            for (int i = 0; i < 20; i++)
            {
                double soma = 0;
                for (int j = 0; j < 3; j++)
                {
                    bool notaValida = false;
                    while (!notaValida)
                    {
                        string input = Interaction.InputBox($"Digite a nota {j + 1} do Aluno {i + 1} (0 a 10):", "Exercício 3");

                        if (double.TryParse(input, out double nota) && nota >= 0 && nota <= 10)
                        {
                            notas[i, j] = nota;
                            soma += nota;
                            notaValida = true;
                        }
                        else
                        {
                            MessageBox.Show("Nota inválida. Digite um valor entre 0 e 10.");
                        }
                    }
                }

                double media = soma / 3;
                resultado += $"Aluno {i + 1}: média: {media:F1}\n";
            }

            MessageBox.Show(resultado, "Resultado Exercício 3");
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmExercicio4 frm4 = new frmExercicio4();
            frm4.Show();
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            frmExercicio5 frm5 = new frmExercicio5();
            frm5.Show();
        }
    }
}
