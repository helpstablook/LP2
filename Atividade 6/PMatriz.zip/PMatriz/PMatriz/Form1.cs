﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] Vetor = new int[20];
            String aux = "";
            for (int i = 0; i < Vetor.Length; i++)
            {
                aux = Interaction.InputBox($"Digite o número {i + 1}", "Entrada de dados");
                if (!int.TryParse(aux, out Vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                }
                i++;
            }
            Array.Reverse(Vetor);
            aux = "";
            foreach (int x in Vetor)
                aux += x + "\n";
            MessageBox.Show(aux);
        }

        private void btnEx2_Click_1(object sender, EventArgs e)
        {
            ArrayList list = new ArrayList();


        }
    }
}
