﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade3
{
    public partial class Atividade3 : Form
    {
        double ValorA, ValorB, ValorC;

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtValorA.Clear();
            txtValorB.Clear();
            txtValorC.Clear();
            ValorA = 0;
            ValorB = 0;
            ValorC = 0;
            txtValorA.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtValorC_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtValorA_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        public Atividade3()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if
                /*O método TryParse tenta converter a string em um número e retorna
                um valor booleano indicando se a conversão foi bem-sucedida ou não.
                Se a conversão falhar, o valor da variável será definido como zero.*/
                (!double.TryParse(txtValorA.Text, out ValorA) ||
                !double.TryParse(txtValorB.Text, out ValorB) ||
                !double.TryParse(txtValorC.Text, out ValorC) ||
                    ValorA <= 0 || ValorB <= 0 || ValorC <= 0)
            {
                MessageBox.Show("Por favor, insira valores numéricos válidos para os lados do triângulo.");
                return;
            }
                
            if
            /* Para que os valores possam formar um triângulo,
            é necessário que a soma de dois lados seja sempre maior
            do que o terceiro lado.*/
            ((ValorA < (ValorB + ValorC)) &&
            (ValorA > (ValorB - ValorC)) &&
            (ValorB < (ValorA + ValorC)) &&
            (ValorB > (ValorA - ValorC)) &&
            (ValorC < (ValorA + ValorB)) &&
            (ValorC > (ValorA - ValorB)))
            {
                /*O triângulo equilátero é aquele que possui os três lados iguais, 
                 ou seja, quando os três lados possuem o mesmo valor.*/
                if (ValorA == ValorB && ValorB == ValorC)
                {
                    lblResultado.Text = "Os valores formam um triângulo equilátero.";
                }
                /* O triângulo isósceles é aquele que possui dois lados iguais
                e um diferente, ou seja, quando apenas dois dos lados são iguais.*/
                else if (ValorA == ValorB || ValorB == ValorC || ValorA == ValorC)
                {
                    lblResultado.Text = "Os valores formam um triângulo isósceles.";
                }
                /*O triângulo escaleno é aquele que possui os três lados diferentes, 
                 ou seja, quando os três lados possuem valores distintos.*/
                else if (ValorA != ValorB && ValorB != ValorC && ValorA != ValorC)
                {
                    lblResultado.Text = "Os valores formam um triângulo escaleno.";
                }

            }
        }
    }
}
